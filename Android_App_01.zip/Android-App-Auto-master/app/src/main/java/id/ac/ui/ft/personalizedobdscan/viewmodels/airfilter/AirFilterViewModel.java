package id.ac.ui.ft.personalizedobdscan.viewmodels.airfilter;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

public class AirFilterViewModel extends AndroidViewModel {
    public AirFilterViewModel(@NonNull Application application) {
        super(application);
    }
}
