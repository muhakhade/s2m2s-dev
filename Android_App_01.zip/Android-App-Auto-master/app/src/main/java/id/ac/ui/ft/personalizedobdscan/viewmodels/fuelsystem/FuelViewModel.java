package id.ac.ui.ft.personalizedobdscan.viewmodels.fuelsystem;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

public class FuelViewModel extends AndroidViewModel {
    public FuelViewModel(@NonNull Application application) {
        super(application);
    }
}
