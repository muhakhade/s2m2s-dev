package id.ac.ui.ft.personalizedobdscan.models.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EmissionSystemResponse {
    @SerializedName("avg_co2")
    @Expose
    private Double avgCo2;
    @SerializedName("co2persec")
    @Expose
    private Double co2Persec;
    @SerializedName("totalco2")
    @Expose
    private Double totalCo2;

    public Double getAvgCo2() {
        return avgCo2;
    }

    public void setAvgCo2(Double avgCo2) {
        this.avgCo2 = avgCo2;
    }

    public Double getCo2Persec() {
        return co2Persec;
    }

    public void setCo2Persec(Double co2Persec) {
        this.co2Persec = co2Persec;
    }

    public Double getTotalCo2() {
        return totalCo2;
    }

    public void setTotalCo2(Double totalCo2) {
        this.totalCo2 = totalCo2;
    }

}
